# Design Decisions Log — JPEGmini Video Sharing Platform

---

## October 2025 — Video Sharing Flow

### Decision: Dark Theme as Primary
- **Rationale**: Professional media/creative tool aesthetic. Consistent with industry tools (Frame.io, DaVinci Resolve). Reduces eye strain for users working with video content.
- **Alternatives considered**: Light theme (rejected — doesn't match the professional video tool positioning)
- **Impact**: All surfaces, text, and components follow dark theme token system.

### Decision: UI Inspiration from Frame.io, UX Inspiration from WeTransfer
- **Rationale**: Frame.io represents best-in-class professional video UI. WeTransfer represents best-in-class sharing simplicity. Combining both creates a professional tool that doesn't overcomplicate sharing.
- **Impact**: Component styling leans professional/dense (Frame.io). Sharing flows lean minimal/zero-friction (WeTransfer).

### Decision: One Link Per Video
- **Rationale**: Simplicity. Each video is a self-contained shareable unit. No need to select formats before sharing — all formats are included in the link.
- **Impact**: Share modal generates one link. Landing page shows all available formats.

### Decision: No Compression Stats in Shared View
- **Rationale**: Recipients don't care about compression ratios. They care about watching and downloading. Before/After stats are an internal owner feature.
- **Impact**: Landing page shows only final video metadata. Workspace (owner view) will show compression stats.

### Decision: Split Layout for Owner Share Flow (40/60)
- **Rationale**: Owner needs video context while configuring share settings. 40% for video preview gives enough visual context without competing with the share form.
- **Impact**: Share flow is a two-column layout, not a modal overlay.

---

## February 2026 — Workspace (Upcoming)

### Decision: Card-Based Grid for Workspace
- **Rationale**: TBD — to be validated during design. Video content is highly visual, card grid allows thumbnail preview.
- **Status**: Proposed, not yet implemented.
